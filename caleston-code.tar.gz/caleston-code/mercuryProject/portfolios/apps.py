from django.apps import AppConfig


class PortfoliosConfig(AppConfig):
    name = 'portfolios'
